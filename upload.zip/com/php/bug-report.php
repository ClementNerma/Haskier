<?php

header("HTTP/1.0 404 Not Found");
echo('Bugs reporting is not supported for PHP versions of Haskier. Sorry !');
